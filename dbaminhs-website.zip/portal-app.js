var signupType='s';
var accounts=[
{id:'student',pw:'student123',type:'student',fname:'Juan',lname:'Dela Cruz',grade:'Grade 10 - Rizal',lrn:'136789012345'},
{id:'teacher',pw:'teacher123',type:'teacher',fname:'Elena',lname:'Bautista',dept:'Mathematics',eid:'T-2024-001'},
{id:'parent',pw:'parent123',type:'parent',fname:'Roberto',lname:'Dela Cruz',childLrn:'136789012345',childName:'Juan Dela Cruz'}
];

// Load signup accounts from Firebase (loaded via loadAllFromFirebase)
function loadSavedAccounts() {
  var saved = loadData('accounts', []);
  saved.forEach(function(a) {
    if (!accounts.find(function(x) { return x.id === a.id; })) {
      accounts.push(a);
    }
  });
}

var curUser=null;

// === RENDER DYNAMIC CONTENT FROM SHARED DATA ===
function renderPortalContent() {
  console.log('renderPortalContent called!');
  // Render stats from settings
  var settings = loadData('settings', DEFAULT_SETTINGS);
  var s1=document.getElementById('pStat1');
  var s2=document.getElementById('pStat2');
  var s3=document.getElementById('pStat3');
  var s4=document.getElementById('pStat4');
  if(s1 && settings.stat1) s1.textContent=settings.stat1;
  if(s2 && settings.stat2) s2.textContent=settings.stat2;
  if(s3 && settings.stat3) s3.textContent=settings.stat3;
  if(s4 && settings.stat4) s4.textContent=settings.stat4;
  var news = loadData('news', DEFAULT_NEWS);
  var events = loadData('events', DEFAULT_EVENTS);
  var published = news.filter(function(n) { return n.status === 'Published'; });
  var upcoming = events.filter(function(e) { return e.status === 'Upcoming'; });

  // Render news
  var newsEl = document.getElementById('portalNews');
  console.log('portalNews element:', newsEl ? 'FOUND' : 'NOT FOUND');
  console.log('Published news:', published.length);
  if (newsEl && published.length > 0) {
    var colors = ['ni-a','ni-b','ni-c','ni-d'];
    var icons = ['&#127942;','&#128227;','&#127793;','&#128218;'];
    var html = '';
    // Main featured
    var feat = published[0];
    html += '<div class="ncard nmain"><div class="nimg ' + (feat.image ? '" style="background:none' : colors[0]) + '">' + (feat.image ? '<img src="'+feat.image+'" style="width:100%;height:100%;object-fit:cover">' : icons[0]) + '</div><span class="nbadge">Featured</span><div class="nbody"><div class="ndate">' + formatDate(feat.date) + '</div><h3>' + feat.title + '</h3><p>' + (feat.content || '') + '</p><a href="#" class="nlink">Read more &#8594;</a></div></div>';
    // Side cards
    for (var i = 1; i < Math.min(published.length, 3); i++) {
      var n = published[i];
      html += '<div class="ncard"><div class="nimg ' + (n.image ? '" style="background:none' : colors[i % 4]) + '">' + (n.image ? '<img src="'+n.image+'" style="width:100%;height:100%;object-fit:cover">' : icons[i % 4]) + '</div><div class="nbody"><div class="ndate">' + formatDate(n.date) + '</div><h3>' + n.title + '</h3><p>' + (n.content || '') + '</p><a href="#" class="nlink">Read more &#8594;</a></div></div>';
    }
    newsEl.innerHTML = html;
  }

  // Render events
  var evEl = document.getElementById('portalEvents');
  console.log('portalEvents element:', evEl ? 'FOUND' : 'NOT FOUND');
  console.log('Upcoming events:', upcoming.length);
  if (evEl && upcoming.length > 0) {
    var ehtml = '';
    upcoming.forEach(function(e) {
      var ds = formatDateShort(e.date);
      ehtml += '<div class="ecard"><div class="ebox"><div class="m">' + ds.month + '</div><div class="d">' + ds.day + '</div></div><div class="einfo"><h3>' + e.name + '</h3><p>' + (e.desc || '') + '</p></div><div class="etime">' + e.time + '</div></div>';
    });
    evEl.innerHTML = ehtml;
  }
}

// Run on page load
// Run immediately since script is at bottom of body
// Load data from Firebase, then render
loadAllFromFirebase(function() {
  try {
    renderPortalContent();
    console.log('Portal content rendered from Firebase!');
  } catch(e) {
    console.error('renderPortalContent ERROR:', e);
  }
});
// Listen for real-time changes from admin
listenForChanges(function() {
  renderPortalContent();
  console.log('Real-time update received!');
});

// Real-time updates handled by Firebase listener above

// === AUTH FUNCTIONS ===
function openM(m){document.getElementById('authModal').classList.add('act');switchMode(m||'login')}
function closeM(){document.getElementById('authModal').classList.remove('act')}
function switchMode(m){var l=m==='login';document.getElementById('loginForm').style.display=l?'block':'none';document.getElementById('signupForm').style.display=l?'none':'block';document.getElementById('mtL').className='tab'+(l?' act':'');document.getElementById('mtS').className='tab'+(l?'':' act')}
function stab(el){el.parentElement.querySelectorAll('.tab').forEach(function(t){t.className='tab'});el.className='tab act'}
function stype(el,t){stab(el);signupType=t;document.getElementById('fLrn').style.display=t==='s'?'block':'none';document.getElementById('fEmp').style.display=t==='t'?'block':'none';document.getElementById('fChild').style.display=t==='p'?'block':'none';document.getElementById('fGrade').style.display=t==='s'?'grid':'none'}

function doLogin(){
loadSavedAccounts();
var id=document.getElementById('liId').value.trim().toLowerCase();
var pw=document.getElementById('liPw').value;
var user=accounts.find(function(a){return (a.id===id||a.lrn===id||a.eid===id||(a.email&&a.email.toLowerCase()===id))&&a.pw===pw});
if(!user){toast('Invalid credentials. Please check your ID and password.','er');return}
curUser=user;closeM();
document.getElementById('publicSite').style.display='none';
if(user.type==='student'){
document.getElementById('studentDash').classList.add('act');
document.getElementById('sdAv').textContent=user.fname[0];
document.getElementById('sdName').textContent=user.fname+' '+user.lname;
document.getElementById('sdWelcome').textContent=user.fname;
}else if(user.type==='teacher'){
document.getElementById('teacherDash').classList.add('act');
document.getElementById('tdAv').textContent=user.fname[0];
document.getElementById('tdName').textContent=user.fname+' '+user.lname;
document.getElementById('tdWelcome').textContent=user.fname;
}else if(user.type==='parent'){
document.getElementById('parentDash').classList.add('act');
document.getElementById('pdAv').textContent=user.fname[0];
document.getElementById('pdName').textContent=user.fname+' '+user.lname;
document.getElementById('pdWelcome').textContent=user.fname;
document.getElementById('pdChild').textContent=user.childName||'Your Child';
}
toast('Welcome, '+user.fname+'!');
}

function doLogout(){
curUser=null;
document.querySelectorAll('.dash-page').forEach(function(p){p.classList.remove('act')});
document.getElementById('publicSite').style.display='block';
window.scrollTo({top:0});
toast('Logged out successfully');
}

function doSignup(){
var fn=document.getElementById('sf').value.trim();
var ln=document.getElementById('sl').value.trim();
var em=document.getElementById('se').value.trim();
var p1=document.getElementById('sp1').value;
var p2=document.getElementById('sp2').value;
var ag=document.getElementById('sag').checked;
if(!fn||!ln){toast('Please enter your full name.','er');return}
if(!em){toast('Please enter email.','er');return}
if(!p1||p1.length<8){toast('Password must be at least 8 characters.','er');return}
if(p1!==p2){toast('Passwords do not match.','er');return}
if(!ag){toast('Please agree to Terms & Conditions.','er');return}
var newAcc={id:em.toLowerCase(),pw:p1,type:signupType==='s'?'student':signupType==='t'?'teacher':'parent',fname:fn,lname:ln,email:em};
if(signupType==='s'){
newAcc.lrn=document.getElementById('sLrn').value;
newAcc.grade=(document.getElementById('sGrade').value||'TBA')+' - '+(document.getElementById('sSec').value||'TBA');
if(!newAcc.lrn){toast('Please enter LRN.','er');return}
newAcc.id=newAcc.lrn;
}else if(signupType==='t'){
newAcc.eid=document.getElementById('sEmp').value;
newAcc.dept='TBA';
if(!newAcc.eid){toast('Please enter Employee ID.','er');return}
newAcc.id=newAcc.eid;
}else{
newAcc.childLrn=document.getElementById('sChild').value;
newAcc.childName='Your Child';
if(!newAcc.childLrn){toast('Please enter child LRN.','er');return}
}
accounts.push(newAcc);
// Save account to Firebase
var accts = loadData('accounts', []);
accts.push(newAcc);
saveData('accounts', accts);
// Add to pending signups - load fresh from Firebase first
db.collection('portal_data').doc('pending').get().then(function(doc) {
  var pending = [];
  if (doc.exists) {
    try { pending = JSON.parse(doc.data().data); } catch(e) { pending = []; }
  }
  var maxId = 0;
  pending.forEach(function(p) { if (p.id > maxId) maxId = p.id; });
  pending.unshift({
    id: maxId + 1,
    name: fn + ' ' + ln,
    type: newAcc.type.charAt(0).toUpperCase() + newAcc.type.slice(1),
    email: em,
    idnum: newAcc.lrn || newAcc.eid || newAcc.childLrn || '',
    date: new Date().toISOString().split('T')[0]
  });
  saveData('pending', pending);
  console.log('Signup added to pending! Total pending:', pending.length);
}).catch(function(err) {
  console.error('Error adding to pending:', err);
});

toast('Account created! Welcome, '+fn+'! You can now log in.');
switchMode('login');
document.getElementById('liId').value=newAcc.id;
document.getElementById('liPw').value='';
}

function sdTab(el,id){el.parentElement.querySelectorAll('button').forEach(function(b){b.className=''});el.className='act';['sdGrades','sdSched','sdTasks','sdAtt'].forEach(function(x){document.getElementById(x).style.display=x===id?'block':'none'})}
function tdTab(el,id){el.parentElement.querySelectorAll('button').forEach(function(b){b.className=''});el.className='act';['tdClasses','tdGrade','tdAnnounce'].forEach(function(x){document.getElementById(x).style.display=x===id?'block':'none'})}
function pdTab(el,id){el.parentElement.querySelectorAll('button').forEach(function(b){b.className=''});el.className='act';['pdGrades','pdAtt','pdMsg'].forEach(function(x){document.getElementById(x).style.display=x===id?'block':'none'})}

var tt;
function toast(m,c){
var t=document.getElementById('toastEl');
if(!t)return;
t.textContent=m;
t.className='toast'+(c==='er'?' er':'')+' show';
clearTimeout(tt);
tt=setTimeout(function(){t.classList.remove('show')},3500);
}

window.addEventListener('scroll',function(){
var nb=document.getElementById('navbar');
var st=document.getElementById('stt');
if(nb)nb.classList.toggle('scrolled',window.scrollY>50);
if(st)st.classList.toggle('vis',window.scrollY>400);
});

document.querySelectorAll('a[href^="#"]').forEach(function(a){
a.addEventListener('click',function(e){
var h=this.getAttribute('href');
if(h&&h.length>1){
e.preventDefault();
var t=document.querySelector(h);
if(t){t.scrollIntoView({behavior:'smooth'});var nl=document.querySelector('.nlinks');if(nl)nl.classList.remove('open')}
}
});
});

var lpw=document.getElementById('liPw');
if(lpw)lpw.addEventListener('keydown',function(e){if(e.key==='Enter')doLogin()});

// ============================================
// GRADE UPLOAD SYSTEM
// ============================================

function downloadTemplate() {
  var cls = document.getElementById('gradeClass').value;
  var qtr = document.getElementById('gradeQuarter').value;
  var subject = document.getElementById('gradeSubject').value;
  
  // Get students for this class from localStorage
  var students = loadData('students', DEFAULT_STUDENTS);
  var classStudents = students.filter(function(s) { return s.grade === cls && s.status === 'Active'; });
  
  // If no students found for exact match, show all active students
  if (classStudents.length === 0) {
    classStudents = students.filter(function(s) { return s.status === 'Active'; });
  }
  
  var csv = 'LRN,Student Name,Grade\n';
  classStudents.forEach(function(s) {
    csv += s.lrn + ',' + s.name + ',\n';
  });
  
  var blob = new Blob([csv], {type: 'text/csv'});
  var url = URL.createObjectURL(blob);
  var a = document.createElement('a');
  a.href = url;
  a.download = 'grades_' + cls.replace(/\s/g,'_') + '_Q' + qtr + '_' + subject + '.csv';
  a.click();
  URL.revokeObjectURL(url);
  
  showUploadStatus('Template downloaded! Open in Excel, fill in grades, save as CSV, then upload.', 'success');
}

function handleCSVUpload(event) {
  var file = event.target.files[0];
  if (!file) return;
  
  var reader = new FileReader();
  reader.onload = function(e) {
    var text = e.target.result;
    var lines = text.trim().split('\n');
    
    if (lines.length < 2) {
      showUploadStatus('Error: CSV file is empty or has no data rows.', 'error');
      return;
    }
    
    // Parse header
    var header = lines[0].split(',');
    if (header.length < 3) {
      showUploadStatus('Error: CSV must have 3 columns: LRN, Student Name, Grade', 'error');
      return;
    }
    
    // Parse data rows
    var grades = [];
    var errors = [];
    for (var i = 1; i < lines.length; i++) {
      var row = lines[i].split(',');
      if (row.length < 3 || !row[0].trim()) continue;
      
      var lrn = row[0].trim();
      var name = row[1].trim();
      var grade = parseFloat(row[2].trim());
      
      if (isNaN(grade)) {
        errors.push('Row ' + (i+1) + ': "' + name + '" - invalid grade');
        continue;
      }
      if (grade < 60 || grade > 100) {
        errors.push('Row ' + (i+1) + ': "' + name + '" - grade must be 60-100');
        continue;
      }
      
      grades.push({lrn: lrn, name: name, grade: Math.round(grade * 10) / 10});
    }
    
    if (grades.length === 0) {
      showUploadStatus('Error: No valid grades found in file. ' + (errors.length > 0 ? errors.join('; ') : ''), 'error');
      return;
    }
    
    // Show preview
    var cls = document.getElementById('gradeClass').value;
    var qtr = document.getElementById('gradeQuarter').value;
    var subject = document.getElementById('gradeSubject').value;
    var qtrLabel = ['','1st','2nd','3rd','4th'][parseInt(qtr)] + ' Quarter';
    
    var html = '<div style="margin-bottom:12px"><strong>' + grades.length + ' students</strong> parsed from CSV';
    if (errors.length > 0) html += ' <span style="color:var(--da)">(' + errors.length + ' errors skipped)</span>';
    html += '</div>';
    html += '<table><thead><tr><th>LRN</th><th>Student Name</th><th>Grade</th><th>Remarks</th></tr></thead><tbody>';
    grades.forEach(function(g) {
      var remarks = g.grade >= 75 ? 'Passed' : 'Failed';
      var badge = g.grade >= 75 ? 'b-g' : 'b-r';
      html += '<tr><td style="font-family:monospace;font-size:12px">' + g.lrn + '</td><td>' + g.name + '</td><td><strong>' + g.grade + '</strong></td><td><span class="badge ' + badge + '">' + remarks + '</span></td></tr>';
    });
    html += '</tbody></table>';
    html += '<div style="display:flex;gap:10px;margin-top:16px">';
    html += '<button class="btn btn-p btn-sm" onclick="saveUploadedGrades()">&#128190; Save Grades for ' + qtrLabel + '</button>';
    html += '<button class="btn btn-s btn-sm" onclick="cancelUpload()">Cancel</button>';
    html += '</div>';
    
    document.getElementById('gradePreview').innerHTML = html;
    
    // Store temporarily
    window._pendingGrades = grades;
    window._pendingMeta = {cls: cls, qtr: qtr, subject: subject};
    
    showUploadStatus('CSV parsed successfully! Review grades below and click Save.', 'success');
  };
  reader.readAsText(file);
  event.target.value = '';
}

function saveUploadedGrades() {
  if (!window._pendingGrades || !window._pendingMeta) {
    toast('No grades to save. Upload a CSV first.', 'er');
    return;
  }
  
  var meta = window._pendingMeta;
  var grades = window._pendingGrades;
  var key = 'grades_' + meta.cls.replace(/\s/g,'_') + '_' + meta.subject;
  
  // Load existing grades for this class+subject
  var existing = loadData(key, {});
  
  // Update grades for the selected quarter
  grades.forEach(function(g) {
    if (!existing[g.lrn]) {
      existing[g.lrn] = {name: g.name, q1: '', q2: '', q3: '', q4: ''};
    }
    existing[g.lrn]['q' + meta.qtr] = g.grade;
    existing[g.lrn].name = g.name;
    
    // Calculate final grade
    var total = 0, count = 0;
    for (var q = 1; q <= 4; q++) {
      var val = existing[g.lrn]['q' + q];
      if (val !== '' && val !== undefined) { total += parseFloat(val); count++; }
    }
    existing[g.lrn].final = count > 0 ? Math.round((total / count) * 10) / 10 : '';
  });
  
  saveData(key, existing);
  
  window._pendingGrades = null;
  window._pendingMeta = null;
  document.getElementById('gradePreview').innerHTML = '';
  
  var qtrLabel = ['','1st','2nd','3rd','4th'][parseInt(meta.qtr)] + ' Quarter';
  toast(grades.length + ' grades saved for ' + qtrLabel + '! Students can now view their grades.');
  showUploadStatus(grades.length + ' grades saved successfully for ' + meta.cls + ' - ' + qtrLabel + '!', 'success');
  
  updateGradeView();
}

function cancelUpload() {
  window._pendingGrades = null;
  window._pendingMeta = null;
  document.getElementById('gradePreview').innerHTML = '';
  document.getElementById('uploadStatus').style.display = 'none';
}

function updateGradeView() {
  var cls = document.getElementById('gradeClass').value;
  var subject = document.getElementById('gradeSubject').value;
  var key = 'grades_' + cls.replace(/\s/g,'_') + '_' + subject;
  
  var grades = loadData(key, {});
  var lrns = Object.keys(grades);
  
  var el = document.getElementById('savedGrades');
  if (lrns.length === 0) {
    el.innerHTML = '<div style="text-align:center;padding:24px;color:var(--g5);font-size:14px">No grades uploaded yet for this class. Download the template and upload grades.</div>';
    return;
  }
  
  var html = '<h4 style="font-size:15px;margin-bottom:12px">&#128202; Saved Grades &mdash; ' + cls + ' (' + subject + ')</h4>';
  html += '<div style="overflow-x:auto"><table><thead><tr><th>LRN</th><th>Student Name</th><th>Q1</th><th>Q2</th><th>Q3</th><th>Q4</th><th>Final</th><th>Remarks</th></tr></thead><tbody>';
  
  lrns.forEach(function(lrn) {
    var g = grades[lrn];
    var final_grade = g.final || '';
    var remarks = '';
    var badge = '';
    if (final_grade !== '') {
      remarks = final_grade >= 75 ? 'Passed' : 'Failed';
      badge = final_grade >= 75 ? 'b-g' : 'b-r';
    }
    html += '<tr><td style="font-family:monospace;font-size:12px">' + lrn + '</td><td>' + g.name + '</td>';
    html += '<td>' + (g.q1 || '<span style="color:var(--g3)">--</span>') + '</td>';
    html += '<td>' + (g.q2 || '<span style="color:var(--g3)">--</span>') + '</td>';
    html += '<td>' + (g.q3 || '<span style="color:var(--g3)">--</span>') + '</td>';
    html += '<td>' + (g.q4 || '<span style="color:var(--g3)">--</span>') + '</td>';
    html += '<td><strong>' + (final_grade || '--') + '</strong></td>';
    html += '<td>' + (remarks ? '<span class="badge ' + badge + '">' + remarks + '</span>' : '') + '</td>';
    html += '</tr>';
  });
  
  html += '</tbody></table></div>';
  el.innerHTML = html;
}

function showUploadStatus(msg, type) {
  var el = document.getElementById('uploadStatus');
  el.style.display = 'block';
  el.textContent = msg;
  if (type === 'success') {
    el.style.background = 'var(--sub)';
    el.style.color = 'var(--su)';
    el.style.border = '1px solid var(--su)';
  } else {
    el.style.background = 'var(--dab)';
    el.style.color = 'var(--da)';
    el.style.border = '1px solid var(--da)';
  }
}

// Update student dashboard to load grades from Firebase
function loadStudentGrades() {
  if (!curUser || curUser.type !== 'student') return;
  var lrn = curUser.lrn;
  if (!lrn) return;
  
  // Search all grade keys in cache for this student's LRN
  var subjects = [];
  var keys = Object.keys(_cache);
  keys.forEach(function(k) {
    if (k.startsWith('grades_')) {
      var data = _cache[k];
      if (data && data[lrn]) {
        var subjectName = k.split('_').pop();
        subjects.push({subject: subjectName, grades: data[lrn]});
      }
    }
  });
  
  if (subjects.length === 0) return;
  
  var el = document.getElementById('sdGrades');
  if (!el) return;
  
  var html = '<h3>&#128202; My Grades &mdash; Uploaded by Teacher</h3><table><thead><tr><th>Subject</th><th>Q1</th><th>Q2</th><th>Q3</th><th>Q4</th><th>Final</th><th>Remarks</th></tr></thead><tbody>';
  subjects.forEach(function(s) {
    var g = s.grades;
    var remarks = g.final >= 75 ? 'Passed' : (g.final ? 'Failed' : '');
    var badge = g.final >= 75 ? 'b-g' : 'b-r';
    html += '<tr><td>' + s.subject + '</td>';
    html += '<td>' + (g.q1 || '--') + '</td>';
    html += '<td>' + (g.q2 || '--') + '</td>';
    html += '<td>' + (g.q3 || '--') + '</td>';
    html += '<td>' + (g.q4 || '--') + '</td>';
    html += '<td><strong>' + (g.final || '--') + '</strong></td>';
    html += '<td>' + (remarks ? '<span class="badge ' + badge + '">' + remarks + '</span>' : '') + '</td></tr>';
  });
  html += '</tbody></table>';
  el.innerHTML = html;
}

// Hook into login to load grades
var _origLogin = doLogin;
doLogin = function() {
  _origLogin();
  if (curUser) {
    setTimeout(function() { loadStudentGrades(); }, 100);
  }
};
